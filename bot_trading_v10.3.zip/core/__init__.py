"""
core/__init__.py
Módulo core del Trading Bot v10
==============================

Contiene los archivos principales del bot de trading.
"""

__version__ = "1.0.0"
__author__ = "Trading Bot v10"
