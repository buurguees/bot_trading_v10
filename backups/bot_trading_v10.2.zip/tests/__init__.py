"""
🧪 Tests del Trading Bot v10
===========================

Carpeta que contiene todos los tests y pruebas del sistema.
"""

__version__ = "1.0.0"
